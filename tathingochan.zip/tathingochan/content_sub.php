

<div class="sidebar-section newsletter-area">
							<h5 class="title"><b>Subscribe to our newsletter</b></h5>
							
							<div class="subscribe-form">
        
                            <form role="cform" id="cform" method="post" class="s-content__form" action="subsribers.php" enctype="multipart/form-data"  onsubmit="return check_all()">
                                        <fieldset>
                                      
                                      
                                    <div class="form-field">
                                        <input name="sub_email" type="text" id="sub_email" onblur="check_email()" class="h-full-width h-remove-bottom" placeholder="Email"  value="">
                                        <p id="message_email"></p>
                                    </div>
                                   
                                           
                                    <br>
                                    <button type="submit" class="submit btn btn--primary h-full-width" >Submit</button>
                                            </fieldset>
                                        </form>

							</div>
						</div>
				</div><!-- sidebar-section newsletter-area -->
