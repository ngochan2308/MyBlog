<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                 <h3> ADMINISTRATOR</h3>
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="index.php">
                                <i class="fas fa-tachometer-alt"></i>Trang chủ quản trị</a>
                            <!-- <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="index.php">Dashboard 1</a>
                                </li>
                                
                            </ul> -->
                        </li>
                        <li>
                            <a href="blog_categories.php">
                                <i class="fas fa-chart-bar"></i>Blog Categories</a>
                        </li>
                        <li>
                            <a href="blogs.php">
                                <i class="fas fa-table"></i>Blog</a>
                        </li>
                        <li>
                            <a href="write_blog.php">
                                <i class="far fa-check-square"></i>Write a blog</a>
                        </li>
                        <li>
                            <a href="blog_contacts.php">
                                <i class="fas fa-calendar-alt"></i>Blog Contacts</a>
                        </li>
                        <!-- <li>
                            <a href="blog_subscribers.php">
                                <i class="fas fa-map-marker-alt"></i>Blog Subscribers</a>
                        </li> -->
                     
                    </ul>
                </nav>
            </div>
        </aside>