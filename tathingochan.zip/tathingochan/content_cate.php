<div class="sidebar-section category-area">
							<h4 class="title"><b class="light-color">Categories</b></h4>
							<a class="category" href="#">
								<img src="images/category-1-400x150.jpg" alt="Category Image">
								<h6 class="name">TRAVEL</h6>
							</a>

							<a class="category" href="#">
								<img src="images/category-2-400x150.jpg" alt="Category Image">
								<h6 class="name">FASHION</h6>
							</a>

							<a class="category" href="#">
								<img src="images/category-3-400x150.jpg" alt="Category Image">
								<h6 class="name">LIFESTYLE</h6>
							</a>
							<a class="category" href="#">
								<img src="images/category-4-400x150.jpg" alt="Category Image">
								<h6 class="name">DESIGN</h6>
							</a>
						</div><!-- sidebar-section category-area -->