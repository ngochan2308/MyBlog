<div class="sidebar-section instagram-area">
							<h4 class="title"><b class="light-color">Instagram</b></h4>
							<ul class="instagram-img">
								<li><a href="#"><img src="images/instragram-side-1-150x150.jpg" alt="Instagram Image"></a></li>
								<li><a href="#"><img src="images/instragram-side-2-150x150.jpg" alt="Instagram Image"></a></li>
								<li><a href="#"><img src="images/instragram-side-3-150x150.jpg" alt="Instagram Image"></a></li>
								<div class="clearfix"></div>
								<li><a href="#"><img src="images/instragram-side-4-150x150.jpg" alt="Instagram Image"></a></li>
								<li><a href="#"><img src="images/instragram-side-5-150x150.jpg" alt="Instagram Image"></a></li>
								<li><a href="#"><img src="images/instragram-side-6-150x150.jpg" alt="Instagram Image"></a></li>
							</ul>
						</div><!-- sidebar-section instagram-area -->